#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from lxml import etree
import glob
import os
import argparse
import xml.dom.minidom



def format_node(node):
    if isinstance(node, str):
        # Nœud texte
        if node.strip():
            return [node.strip()]
        else:
            return None
    elif isinstance(node, xml.dom.minidom.Element):
        # Élément DOM
        lines = []
        lines.append(f"<{node.tagName}")
        for attr_name, attr_value in node.attributes.items():
            lines.append(f'    {attr_name}="{attr_value}"')


        if len(node.childNodes) > 1:
            lines[len(lines) - 1] += ">"
            child_nodes = [child for child in node.childNodes if format_node(child) is not None]
            if child_nodes:
                for child in child_nodes:
                    child_lines = format_node(child)
                    lines.extend(f"    {line}" for line in child_lines)

            lines.append(f"</{node.tagName}>")
        else:
            lines[len(lines) - 1] += "/>"
        return lines

    return None

# Fonction récursive pour trier les éléments et sous-éléments
def trier_elements(element, nsmap):
    element[:] = sorted(
        element,
        key=lambda child: (
            child.tag,
            sorted(child.attrib.items()),
            child.text,
            [trier_elements(e, nsmap) for e in child]
        )
    )
    # Réattribuer les préfixes de namespace d'origine aux éléments triés
    for child in element:
        child.attrib.update({k: v for k, v in child.attrib.items() if k.startswith("{")})
        trier_elements(child, nsmap)

def trier_file(path):

    # Charger le fichier XML
    tree = etree.parse(path)
    root = tree.getroot()
    nsmap = root.nsmap

    # Trier tous les éléments et sous-éléments
    trier_elements(root, nsmap)

    # Convertir l'arbre lxml en arbre DOM
    xml_string = etree.tostring(root, encoding='utf-8')
    dom = xml.dom.minidom.parseString(xml_string)

    # Générer une version formatée du fichier XML trié
    formatted_lines = format_node(dom.documentElement)
    formatted_xml = "\n".join(formatted_lines)

    # Enregistrer le fichier XML trié et formaté
    with open(path, 'w') as f:
        f.write(formatted_xml)


# Charger chaque fichier XML dans le dossier courant et les sous-dossiers
def trier_doss(path):
    for file in glob.glob(path + '/*'):
        if os.path.isfile(file):
        
            # Check the data in file to see if it contains some XML
            with open(file, 'r') as f:
                data = f.read()
                if not '<' in data:
                    continue
            trier_file(file)
            

    # Pour chaque sous-dossier, appeler la fonction trier_doss
    for folder in glob.glob(path + '/*'):
        if os.path.isdir(folder):
            trier_doss(folder)



if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Trier les éléments et sous-éléments d\'un fichier XML, afin de faciliter la comparaison de fichiers XML.')
    parser.add_argument('file', help='Chemin vers le dossier ou fichier')
    # Option verbose
    parser.add_argument('-v', '--verbose', action='store_true', help='Afficher les informations de débogage')
    args = parser.parse_args()
    file = args.file
    # Appeler la fonction trier_doss avec le dossier courant
    if os.path.isfile(file):
        # Check the data in file to see if it contains some XML
        with open(file, 'r') as f:
            data = f.read()
            if '<' in data:
                trier_file(file)
    else:
        trier_doss(file)


